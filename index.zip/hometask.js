let foods=[
    { id: 1, name: "Pizza", image: "pizza.jpg" },
    { id: 2, name: "Burger", image: "burger.jpg" },
    { id: 3, name: "Pasta", image: "pasta.jpg" },
];

let user=[
    { userId: 1, userName: "Abduraxmon", phone: "+1234567890" },
    { userId: 2, userName: "Muxammadaziz", phone: "+0987654321" },
    { userId: 3, userName: "Azizbek", phone: "+1122334455" },
];

let orders=[
    { id: 1, userId: 1, foodsId: 1, count: 2 },
    { id: 2, userId: 3, foodsId: 2, count: 5 },
    { id: 3, userId: 2, foodsId: 3, count: 4 },
];